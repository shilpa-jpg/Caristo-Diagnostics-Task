import os
from selenium import webdriver
from features.utilities.readProperties import ReadConfig


class Browser:
    driver = webdriver.Chrome(os.getcwd() + "\\webdriver\\chromedriver.exe")
    baseURL = ReadConfig.getApplicationUrl()
    driver.get(baseURL)
    driver.maximize_window()
    driver.set_page_load_timeout(20)

    def close(context):
        context.driver.close()
