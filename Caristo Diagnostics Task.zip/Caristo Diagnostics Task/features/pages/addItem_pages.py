import time
from selenium.webdriver import ActionChains
from features.browser import Browser


class AmazonShopping(Browser):
    # Locators for signIn
    accept_cookies_id = "sp-cc-accept"
    mouse_hover_signIn_id = "nav-link-accountList-nav-line-1"
    click_signIn_xpath = "//span[contains(text(),'Hello, Sign in')]"
    enter_username_id = "ap_email"
    click_continue_id = "continue"
    enter_password_id = "ap_password"
    click_signIn_button_id = "signInSubmit"
    # Locators for empty basket
    clickBasket_xpath = "//a[@class='nav-a nav-a-2 nav-progressive-attribute' and @id = 'nav-cart']"
    emptyBasket_xpath = "//h1[contains(text(),'Your Amazon Basket is empty.')]"
    # locator for click on home
    clickHome_id = "nav-logo-sprites"
    # locator for search item
    searchItem_id = "twotabsearchtextbox"
    clickEnter_xpath = "//input[@id = 'nav-search-submit-button']"
    # locator for select item
    selectItem_xpath = "(//div[@class='sg-col-inner']//img[contains(@data-image-latency,'s-product-image')])[2]"
    selectItemAgain_xpath = "(//div[@class='sg-col-inner']//img[contains(@data-image-latency,'s-product-image')])[5]"
    # locator to add item in basket
    addItemIntoBasket_xpath = "//input[contains(@value,'Add to Basket')]"
    # locator to add item in sub-basket
    sub_addToBasket_xpath = "//button[@id='siAddCoverage-announce']"
    # locator to get basket count
    getBasketCount_xpath = "(//span[contains(text(),' (1 item):')])[1]"

    def clickOnSignIn(self):
        # accept cookies
        self.driver.find_element_by_id(self.accept_cookies_id).click()
        # Mouse hover to Hello,Sign in
        element = self.driver.find_element_by_id(self.mouse_hover_signIn_id)
        actions = ActionChains(self.driver)
        actions.move_to_element(element).perform()
        # Click on Signin
        self.driver.find_element_by_xpath(self.click_signIn_xpath).click()
        # Save the screenshot
        self.driver.save_screenshot(".\\screenshots\\" + "Homepage.png")

    def enter_username(self, username):
        self.driver.find_element_by_id(self.enter_username_id).send_keys(username)
        self.driver.save_screenshot(".\\screenshots\\" + "enterUsername.png")

    def clickOnContinue(self):
        self.driver.find_element_by_id(self.click_continue_id).click()
        self.driver.save_screenshot(".\\screenshots\\" + "clickContinue.png")

    def enter_password(self, password):
        self.driver.find_element_by_id(self.enter_password_id).send_keys(password)
        self.driver.save_screenshot(".\\screenshots\\" + "enterPassword.png")

    def clickOnSignInButton(self):
        self.driver.find_element_by_id(self.click_signIn_button_id).click()
        self.driver.save_screenshot(".\\screenshots\\" + "clickOnSignIn.png")

    def getPageTitle(self):
        title = self.driver.title
        print("Home Page Title:", title)

    def emptyBasket(self):
        # click on basket
        self.driver.find_element_by_xpath(self.clickBasket_xpath).click()
        # Save the screenshot
        self.driver.save_screenshot(".\\screenshots\\" + "clickOnBasket.png")
        # get empty basket text
        cart_count = self.driver.find_element_by_xpath(self.emptyBasket_xpath).text
        assert cart_count == "Your Amazon Basket is empty."
        self.driver.save_screenshot(".\\screenshots\\" + "cartWithZeroItem.png")

    def userSelectsItem(self, enterItem1):
        # click on Home
        self.driver.find_element_by_id(self.clickHome_id).click()
        # Enter text to search box
        self.driver.find_element_by_id(self.searchItem_id).send_keys(enterItem1)
        # click search button
        self.driver.find_element_by_xpath(self.clickEnter_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "searchItem.png")
        # select Item
        self.driver.find_element_by_xpath(self.selectItem_xpath).click()
        try:
            # click on Add to Basket
            self.driver.find_element_by_xpath(self.addItemIntoBasket_xpath).click()
            time.sleep(10)
            self.driver.save_screenshot(".\\screenshots\\" + "addToCart.png")
        except Exception as e:
            print("addItemIntoBasket element is not clickable", e)

        # click on sub-Basket
        self.driver.find_element_by_xpath(self.sub_addToBasket_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "sub-addToCart.png")

    def basketwithOneItem(self):
        # click on basket again
        self.driver.find_element_by_xpath(self.clickBasket_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "basketWithOneItem.png")
        cartCount = self.driver.find_element_by_xpath(self.getBasketCount_xpath).text
        if cartCount == "Subtotal (1 item):":
            print("Cart Count is:" + cartCount)
        elif cartCount == "Subtotal (2 item):":
            print("Cart Count is:" + cartCount)
        elif cartCount == "Subtotal (3 item):":
            print("Cart Count is:" + cartCount)
        else:
            print("Cart Count is not more than zero")

    # method to add items again
    def userAgainSelectsItem(self, enterItem2):
        # click on Home
        self.driver.find_element_by_id(self.clickHome_id).click()
        # Enter text to search box
        self.driver.find_element_by_id(self.searchItem_id).send_keys(enterItem2)
        # click search button
        self.driver.find_element_by_xpath(self.clickEnter_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "searchItemSecond.png")
        # select Item
        self.driver.find_element_by_xpath(self.selectItemAgain_xpath).click()
        try:
            # click on Add to Basket
            self.driver.find_element_by_xpath(self.addItemIntoBasket_xpath).click()
            time.sleep(10)
            self.driver.save_screenshot(".\\screenshots\\" + "addToCartSecond.png")
        except Exception as e:
            print("addItemIntoBasket element is not clickable", e)

        # click on sub-Basket
        self.driver.find_element_by_xpath(self.sub_addToBasket_xpath).click()
        self.driver.save_screenshot(".\\screenshots\\" + "sub-addToCartSecond.png")
