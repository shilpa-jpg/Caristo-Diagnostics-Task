from behave import *


@given('a user is viewing his basket')
def step_impl(context):
    context.delete_item.userClicksOnbasket()


@when('the user changes the quantity of one of the items')
def step_impl(context):
    context.delete_item.userChangesQuantity()


@then('the item quantity changes accordingly')
def step_impl(context):
    context.delete_item.getPageRefresh()


@then('the overall number of items in the basket changes accordingly')
def step_impl(context):
    context.amazon_shopping.basketCount()


@when('the user deletes an items')
def step_impl(context):
    context.delete_item.deleteItem()


@then('the item is no longer present in the basket')
def step_impl(context):
    context.delete_item.getPageRefresh()


@when('the user deletes all items')
def step_impl(context):
    context.delete_item.deleteAllItems()


@then('no items are present in the basket')
def step_impl(context):
    context.amazon_shopping.basketCount()


@then('a message saying the basket is empty is displayed')
def step_impl(context):
    context.amazon_shopping.emptyBasket()
