from behave import *
from hamcrest import *
from features.pages.deleteItem_pages import DeleteItemsAmazon


@given('a user is viewing his basket')
def userViewBasket(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.userClicksOnbasket()


@when('the user changes the quantity of one of the items')
def userChangesQuantity(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.userChangesQuantity()


@then('the item quantity changes accordingly')
def itemQuantity(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.userClicksOnbasket()


@then('the overall number of items in the basket changes accordingly')
def itemsQuantity(context):
    pass


@when('the user deletes an items')
def userDeleteItem(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.deleteItem()
    print("Basket count is 6")


@then('the item is no longer present in the basket')
def itemNotPresentInBasket(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.userClicksOnbasket()


@when('the user deletes all items')
def userDeletesAllItems(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.deleteAllItems()
    print("Basket count is 0")


@then('no items are present in the basket')
def emptyBasketWithNoItems(context):
    pass


@then('a message saying the basket is empty is displayed')
def verifyEmptyBasketText(context):
    context.delete_item = DeleteItemsAmazon()
    context.delete_item.emptyBasketDeleteItems()
    verify_empty_basket_text = "Your Amazon Basket is empty."
    assert_that(has_string(verify_empty_basket_text))
