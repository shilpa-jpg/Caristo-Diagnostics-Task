from behave import *


@given('the user basket has 0 items in it')
def basketWithZeroItem(context):
    context.amazon_shopping.emptyBasket()


@when('the user adds the item to the basket')
def addInitialItem(context):
    context.amazon_shopping.userSelectsItem("TV")


@then('the user basket has 1 items in it')
def basketWithOneItem(context):
    context.amazon_shopping.basketCount()


@given('the user basket has at least 1 item')
def basketWithAtleastOneItem(context):
    context.amazon_shopping.basketCount()


@then('the user basket has one more item in it')
def basketWithMoreItems(context):
    context.amazon_shopping.userSelectsItem("Torch")



