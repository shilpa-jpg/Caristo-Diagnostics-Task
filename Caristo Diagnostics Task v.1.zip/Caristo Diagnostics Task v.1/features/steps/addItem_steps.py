from behave import *
from hamcrest import *


@given('the user basket has "{item_number}" items in it')
def basketWithZeroItem(context, item_number):
    context.amazon_shopping.emptyBasket(item_number)
    verify_empty_basket_text = "Your Amazon Basket is empty."
    assert_that(has_string(verify_empty_basket_text))


@when('the user adds the item to the basket')
def addInitialItem(context):
    context.amazon_shopping.userSelectsItem("TV")


@then('the user basket has "{item_number}" items in it')
def basketWithOneItem(context, item_number):
    context.amazon_shopping.basketCount(item_number)


@given('the user basket has at least "{item_number}" item')
def basketWithAtleastOneItem(context, item_number):
    context.amazon_shopping.basketCount(item_number)


@then('the user basket has one more item in it')
def basketWithMoreItems(context):
    context.amazon_shopping.userSelectsItem("Torch")
