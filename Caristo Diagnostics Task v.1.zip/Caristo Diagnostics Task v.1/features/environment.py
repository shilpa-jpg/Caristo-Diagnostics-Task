from behave_webdriver import driver

from features.browser import Browser
from features.pages.addItem_pages import AmazonShopping
from features.pages.deleteItem_pages import DeleteItemsAmazon
from features.utilities.readProperties import ReadConfig


def before_all(context):
    context.browser = Browser()
    context.amazon_shopping = AmazonShopping()
    context.amazon_shopping.clickOnSignIn()
    username = ReadConfig.getUsername()
    context.amazon_shopping.enter_username(username)
    context.amazon_shopping.clickOnContinue()
    password = ReadConfig.getPassword()
    context.amazon_shopping.enter_password(password)
    context.amazon_shopping.clickOnSignInButton()
    context.amazon_shopping.getPageTitle()
    context.delete_item = DeleteItemsAmazon()


# def after_all(context):
#     context.amazon_shopping.signOut()
#     context.browser.close()
