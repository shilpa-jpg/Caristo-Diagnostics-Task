import time
from selenium.webdriver.support.select import Select
from features.browser import Browser


class DeleteItemsAmazon(Browser):
    # change quantity locators
    clickBasket_xpath = "//a[@id = 'nav-cart']"
    emptyBasket_xpath = "//h1[contains(text(),'Your Amazon Basket is empty.')]"
    clickQuantity_name = "quantity"
    clickHome_id = "nav-logo-sprites"
    # delete item locators
    clickDeleteFirstItem_xpath = "(//div[contains(@class,'a-row sc-action-links')]//span[contains(@class,'sc-action-delete')])[1]"
    clickDeleteAllItem_xpath = "(//div[contains(@class,'a-row sc-action-links')]//span[contains(@class,'sc-action-delete')])"

    # Change item quantity
    def userClicksOnbasket(self):
        self.driver.find_element_by_xpath(self.clickBasket_xpath).click()

    def userChangesQuantity(self):
        element = Select(self.driver.find_element_by_name(self.clickQuantity_name))
        element.select_by_value("3")
        time.sleep(10)
        self.driver.save_screenshot(".\\screenshots\\" + "increaseItemQuantity.png")

    # def basketCountAfterDeleteItem(self):
    #     # click on basket again
    #     self.driver.find_element_by_xpath(self.clickBasket_xpath).click()
    #     self.driver.save_screenshot(".\\screenshots\\" + "basketWithItem.png")
    #     cartCount = int(self.driver.find_element_by_xpath(self.clickBasket_xpath).text)
    #     if cartCount > 1:
    #         print("Cart count:" + str(cartCount))

    # delete item
    def deleteItem(self):
        try:
            element = self.driver.find_element_by_xpath(self.clickDeleteFirstItem_xpath)
            self.driver.execute_script("arguments[0].click();", element)
            print("Item has been deleted successfully")
            self.driver.save_screenshot(".\\screenshots\\" + "deleteFirstItem.png")
        except Exception as e:
            print("Element not clickable", e)

    def emptyBasketDeleteItems(self):
        # click on basket
        self.driver.find_element_by_xpath(self.clickBasket_xpath).click()
        # Save the screenshot
        self.driver.save_screenshot(".\\screenshots\\" + "clickOnBasket.png")
        # get empty basket text
        cart_count = self.driver.find_element_by_xpath(self.emptyBasket_xpath).text
        self.driver.save_screenshot(".\\screenshots\\" + "cartWithZeroItem.png")

    def deleteAllItems(self):
        list1 = self.driver.find_elements_by_xpath(self.clickDeleteAllItem_xpath)
        for l in list1:
            self.driver.execute_script("arguments[0].click();", l)
        self.driver.save_screenshot(".\\screenshots\\" + "deleteSecondItems.png")

    def getPageRefresh(self):
        self.driver.refresh()
